<?php
namespace App\Http\Controllers\Corporativo;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Corporativo;

class CorporativoController extends Controller
{

    public function index()
    {
        $corporativos=Corporativo::All();
        return response(['data'=>$corporativos],200);
    }


    public function store(Request $request)
    {
    $rules=[
          'name'=>'required',
          'email'=>'required|email|unique:corporativos',
          'web'=>'required|url',
          'tel_one'=>'required|min:12',
          'tel_two'=>'min:12',
      ];
      $this->validate($request,$rules);
        $campos= $request->all();
        $corporativo=Corporativo::create($campos);
        return response()->json(['data'=>$corporativo],201);
    }

    public function show($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
