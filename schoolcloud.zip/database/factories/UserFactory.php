<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\User;
use App\Corporativo;
use Faker\Generator as Faker;
use Illuminate\Support\Str;


$factory->define(Corporativo::class, function (Faker $faker) {
    return [
        'name' => $faker->name,
        'email' => $faker->unique()->safeEmail,
        'web' => $faker->domainName,
        'tel_one' => $faker->phoneNumber,
        'tel_two' => $faker->phoneNumber,
    ];
});
