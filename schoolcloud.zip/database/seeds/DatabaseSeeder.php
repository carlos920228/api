<?php

use Illuminate\Database\Seeder;
use App\Corporativo;
class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
      Corporativo::truncate();
      Corporativo::flushEventListeners();
      $cantidad=10;
      factory(Corporativo::class,$cantidad)->create();
    }
}
